export type TTransformToHexArray = (str: string) => number[]
export type TTransformValueToHexStr = (str: string) => string