import { possibleCommandsReceivedForProjectZones } from "../../commands/possible-commands-received-for-project-zones";
import { defineIndexToGoUtility } from "../define-index-to-go-utility";
import { UdpProjectUtilities } from "../udp/udp-projection-zone-utilities";
import { EGameControlCommand } from "../../types/game-types";
import { EInstallationIds } from "../../types/_common-types";
import { IStore } from "../../types/store-types";
import { TCommand } from "../../types/command-types";

export interface IProjectZonesControllerProps {

    id: EInstallationIds
    storeId: keyof IStore
    command: EGameControlCommand | TCommand

}
const projectZonesController = async ({ id, storeId, command }: IProjectZonesControllerProps) => {

    const { goBackwards, goForward } = possibleCommandsReceivedForProjectZones;
    const newIndex = defineIndexToGoUtility({ command, storeId });

    if(( [...goBackwards, ...goForward, ].includes( command ) ||
        command.match( /Test_\w*_[L|R]/ ) || command.match( /[0-9]+/gm )
    ) && newIndex) {

        const udpProjectionZoneUtilities = new UdpProjectUtilities({ storeId, id, newIndex, command });

        if ( // project zones "Map", "Lab", "Cabinet"
            [ EInstallationIds.ProjectMap, EInstallationIds.ProjectLab, EInstallationIds.ProjectCabinet
        ].includes(id) ) {

            await udpProjectionZoneUtilities.sendUniversalTransitionCommand();

        } else if ( // project zone "Portraits"
            EInstallationIds.ProjectPortraits === id
        ) {

            await udpProjectionZoneUtilities.sendTransitionCommandToThePortraitsInstallation();

        } else if ( // project zone "Covers"
            EInstallationIds.ProjectCovers === id
        ) {

            await udpProjectionZoneUtilities.sendTransitionCommandToTheCoversInstallation();

        }
    }

}

export {
    projectZonesController
}