import { possibleCommandsReceivedForProjectZones } from "../../../commands/possible-commands-received-for-project-zones";
import { EInstallationIds, TCommandsStandard } from "../../../types/_common-types";
import { ISendCommandHttpProps } from "../../../types/command-types";
import { defineIndexToGoUtility } from "../../../utilities/define-index-to-go-utility";
import { projectZonesController } from "../../../utilities/project-zones-utility/project-zones-controller";
import { UdpProjectUtilities } from "../../../utilities/udp/udp-projection-zone-utilities";
import { Request, Response } from 'express';
import { actionCommands } from "../../../commands/action-commands";
import { IStore } from "../../../types/store-types";


class HttpMasterController {
    async sendCommand (req: Request, res: Response) {

        const {
            id,
            command,
        }: ISendCommandHttpProps = req.body

        const { hexSingleCommands, goBackwards, goForward } = possibleCommandsReceivedForProjectZones;
        const storeId = `installation${ id }` as keyof IStore;
        const newIndex = defineIndexToGoUtility({ command, storeId });

        if( newIndex ){

            if( hexSingleCommands.includes( command ) ){

                const udpProjectionZoneUtilities = new UdpProjectUtilities({ storeId, id, newIndex, command: actionCommands[ command as TCommandsStandard ] });
                await udpProjectionZoneUtilities.sendHexCommand()

            } else if (
                [ ...goBackwards, ...goForward ].includes( command ) ||
                command.match( /Test_\w*_[L|R]/ ) || command.match( /[0-9]+/gm )
            ){

                await projectZonesController({ id, storeId, command })

            }

        }




        const response = ""
        res.json(response);

    }
    // async switchAnalogControl (req: Request, res: Response) {
    //
    //     const response = await httpServices.switchAnalogControl({...req.body});
    //     res.json(response);
    //
    // }
}
const controller = new HttpMasterController();

export { controller };