//encoders
const encoderN = document.querySelector(".encoderN");
const encoderI = document.querySelector(".encoderI");
const encoderII = document.querySelector(".encoderII");
const encoderIII = document.querySelector(".encoderIII");

//buttons
const buttonNA = document.querySelector(".buttonNA");
const buttonNB = document.querySelector(".buttonNB");
const buttonNC = document.querySelector(".buttonNC");
const buttonND = document.querySelector(".buttonND");
const buttonIA = document.querySelector(".buttonIA");
const buttonIB = document.querySelector(".buttonIB");
const buttonIC = document.querySelector(".buttonIC");
const buttonIIA = document.querySelector(".buttonIIA");
const buttonIIB = document.querySelector(".buttonIIB");
const buttonIIC = document.querySelector(".buttonIIC");
const buttonIIIA = document.querySelector(".buttonIIIA");
const buttonIIIB = document.querySelector(".buttonIIIB");
const buttonIIIC = document.querySelector(".buttonIIIC");

const encodersObject = {
    encoderN, encoderI, encoderII, encoderIII
}

const buttonsObject = {
    buttonNA, buttonNB, buttonNC, buttonND,
    buttonIA, buttonIB, buttonIC,
    buttonIIA, buttonIIB, buttonIIC,
    buttonIIIA, buttonIIIB, buttonIIIC
}

const store = {
    encoderN: {
        commandLeft: "Encoder_N_LEFT",
        commandRight: "Encoder_N_Right"
    }, encoderI: {
        commandLeft: "Encoder_I_LEFT",
        commandRight: "Encoder_I_Right"
    }, encoderII: {
        commandLeft: "Encoder_II_LEFT",
        commandRight: "Encoder_II_Right"
    }, encoderIII: {
        commandLeft: "Encoder_III_LEFT",
        commandRight: "Encoder_III_Right"
    },
    buttonNA: {
        command: "Button_N_A"
    }, buttonNB: {
        command: "Button_N_B"
    }, buttonNC: {
        command: "Button_N_C"
    }, buttonND: {
        command: "Button_N_D"
    },
    buttonIA: {
        command: "Button_I_A"
    }, buttonIB: {
        command: "Button_I_B"
    }, buttonIC: {
        command: "Button_I_C"
    },
    buttonIIA: {
        command: "Button_II_A"
    }, buttonIIB: {
        command: "Button_II_B"
    }, buttonIIC: {
        command: "Button_II_C"
    },
    buttonIIIA: {
        command: "Button_III_A"
    }, buttonIIIB: {
        command: "Button_III_B"
    }, buttonIIIC: {
        command: "Button_III_C"
    }
}

function calculateRotation( e, encoder ){
    return e.clientX - store[`${encoder}`].positionX + e.clientY - store[`${encoder}`].positionY
}

async function returnToZeroPosition( encoder ){

    if(store[`${ encoder }`].isHold){
        store[`${ encoder }`].isHold = false;
        store[`${ encoder }`].positionX = 0;
        store[`${ encoder }`].positionY = 0;
        const deg = encodersObject[ encoder ].style.transform.replace(/((?!\d|[-+]).)+/gm,"");
        encodersObject[ encoder ].style.transform = `rotate(${0}deg)`;
        if( deg > 0){
            await gameApi( store[ encoder ].commandRight )
        } else {
            await gameApi( store[ encoder ].commandLeft )
        }

    }

}

function bindEventListeners() {
    Object.keys(encodersObject).forEach(( encoder )=>{

        encodersObject[ encoder ].addEventListener("mousedown", function(e) {
            store[`${ encoder }`].isHold = true;
            store[`${ encoder }`].positionX = e.clientX;
            store[`${ encoder }`].positionY = e.clientY;
        });

        encodersObject[ encoder ].addEventListener("mousemove", function(e) {
            if( store[`${ encoder }`].isHold ){
                const pitch = calculateRotation(e,  encoder )
                    encodersObject[ encoder ].style.transform = `rotate(${pitch}deg)`
            }
        });

        encodersObject[ encoder ].addEventListener("mouseup", async function() {
            await returnToZeroPosition( encoder );
        });

        encodersObject[ encoder ].addEventListener("mouseout", async function() {
            await returnToZeroPosition( encoder );
        });

    })
    
    Object.keys(buttonsObject).forEach((button)=>{
        buttonsObject[ button ].addEventListener("mousedown", async function() {

            await gameApi( store[ button ].command )
        })
    })
}

 async function gameApi(command) {

     const url = `http://192.168.0.228:9019/game-control-panel`;
     // console.log( command );
     await fetch(url, {
         method: "POST",
         headers: {
             'Content-Type': 'application/json;charset=utf-8'
         },
         body: JSON.stringify({
             command
         })
     })

}

bindEventListeners()
